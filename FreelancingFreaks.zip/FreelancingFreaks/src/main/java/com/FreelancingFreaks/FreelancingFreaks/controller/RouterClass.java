package com.FreelancingFreaks.FreelancingFreaks.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.FreelancingFreaks.FreelancingFreaks.model.AdminClass;

@Controller
public class RouterClass {
	
	@Autowired
	 
	 
	@GetMapping("/")
	public String index()
	{
		return "index.html";
	}
	
	@GetMapping("/login")
	public String Login(Model model)
	{
		model.addAttribute("AdminKey",new AdminClass());
		return "Login.html";
	}
	

	@GetMapping("/signup")
	public String signup(Model model)
	{
		model.addAttribute("add",new AdminClass());
		return "Signup.html";
	}
	
	@PostMapping("/userCheck")
	public String checkVal(AdminClass admin,Model model)
	{
		System.out.println(admin.getUsername());
		return "redirect:/signup";
	}
	
	@PostMapping("/emailCheck")
	public String checkemail(AdminClass admin,Model model)
	{
		System.out.println(admin.getEmail());
		return "redirect:/signup";
	}
	
	@PostMapping("/passCheck")
	public String checkpass(AdminClass admin,Model model)
	{
		System.out.println(admin.getPassword());
		return "redirect:/signup";
	}
	
	
}
