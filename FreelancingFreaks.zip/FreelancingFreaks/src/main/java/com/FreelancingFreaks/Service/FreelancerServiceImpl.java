package com.FreelancingFreaks.Service;

import com.FreelancingFreaks.FreelancingFreaks.model.FreelancerClass;

public class FreelancerServiceImpl implements FreelancerService {

	@Override
	public FreelancerClass createFreelancer(FreelancerClass freelancerclass) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FreelancerClass updateFreelancer(FreelancerClass freelancerclass) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteFreelancer(long FreelancerId) {
		// TODO Auto-generated method stub
		
	}

}
