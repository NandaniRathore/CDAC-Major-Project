package com.FreelancingFreaks.FreelancingFreaks.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FreelancingFreaks.FreelancingFreaks.model.ClientClass;

public interface ClientRepository extends JpaRepository <ClientClass,Long>{

}
