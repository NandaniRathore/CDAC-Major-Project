package com.FreelancingFreaks.FreelancingFreaks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreelancingFreaksApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreelancingFreaksApplication.class, args);
		System.out.println("test this");
	}

}
