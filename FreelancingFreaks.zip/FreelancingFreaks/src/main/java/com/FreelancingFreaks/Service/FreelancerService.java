package com.FreelancingFreaks.Service;

import com.FreelancingFreaks.FreelancingFreaks.model.ClientClass;
import com.FreelancingFreaks.FreelancingFreaks.model.FreelancerClass;

public interface FreelancerService {
	
	FreelancerClass createFreelancer(FreelancerClass freelancerclass );
	FreelancerClass updateFreelancer(FreelancerClass freelancerclass);
	
	void deleteFreelancer(long FreelancerId);

}
