package com.FreelancingFreaks.FreelancingFreaks.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FreelancingFreaks.FreelancingFreaks.model.FreelancerClass;

public interface FreelancerRepository  extends JpaRepository <FreelancerClass, Long>{

}
