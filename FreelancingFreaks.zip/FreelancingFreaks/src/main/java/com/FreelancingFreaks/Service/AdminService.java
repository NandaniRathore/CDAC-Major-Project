package com.FreelancingFreaks.Service;

import com.FreelancingFreaks.FreelancingFreaks.model.AdminClass;

public interface AdminService {
 
	AdminClass createAdmin(AdminClass adminclass );
	AdminClass updateAdmin(AdminClass adminclass );
	
	void deleteAdmin(long AdminId);
	
	
}
