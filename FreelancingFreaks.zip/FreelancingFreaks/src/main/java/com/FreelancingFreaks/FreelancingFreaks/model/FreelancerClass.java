package com.FreelancingFreaks.FreelancingFreaks.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Client")
public class FreelancerClass {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name="Username")
	private String username;
	
	@Column(name="Email")
	private String email;
	
	@Column(name="Password")
	private String password;
	

	/*
	 * public String getConfirm_password() { return confirm_password; }
	 * 
	 * @Override public String toString() { return
	 * "FreelancerClass [confirm_password=" + confirm_password + "]"; }
	 * 
	 * 
	 * public void setConfirm_password(String confirm_password) {
	 * this.confirm_password = confirm_password; }
	 * 
	 * @Column(name="ConfirmPassword") private String confirm_password;
	 */
	
	@Column(name="Technology")
	private String technology;
	
	@Column(name="Total_Projects")
	private String total_projects;
}
