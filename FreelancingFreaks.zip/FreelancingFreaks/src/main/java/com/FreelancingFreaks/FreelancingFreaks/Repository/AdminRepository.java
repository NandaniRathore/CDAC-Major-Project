package com.FreelancingFreaks.FreelancingFreaks.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FreelancingFreaks.FreelancingFreaks.model.AdminClass;

public interface AdminRepository extends JpaRepository <AdminClass,Long>{

}
