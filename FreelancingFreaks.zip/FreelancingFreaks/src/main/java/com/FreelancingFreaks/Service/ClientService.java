package com.FreelancingFreaks.Service;

import com.FreelancingFreaks.FreelancingFreaks.model.AdminClass;
import com.FreelancingFreaks.FreelancingFreaks.model.ClientClass;

public interface ClientService {

	
	ClientClass createClient(ClientClass clientclass );
	ClientClass updateClient(ClientClass clientclass);
	
	void deleteClient(long AdminId);
}
