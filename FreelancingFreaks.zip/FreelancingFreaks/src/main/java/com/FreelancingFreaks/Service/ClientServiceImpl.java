package com.FreelancingFreaks.Service;

import com.FreelancingFreaks.FreelancingFreaks.Repository.ClientRepository;
import com.FreelancingFreaks.FreelancingFreaks.model.ClientClass;

public class ClientServiceImpl implements ClientService{

	private ClientRepository clientrepo;
	public ClientClass createClient(ClientClass clientclass) {
		// TODO Auto-generated method stub
		return clientrepo.save(clientclass);
	}

	public ClientClass updateClient(ClientClass clientclass) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteClient(long AdminId) {
		// TODO Auto-generated method stub
		
	}

}
