package com.FreelancingFreaks.Service;

import com.FreelancingFreaks.FreelancingFreaks.Repository.AdminRepository;
import com.FreelancingFreaks.FreelancingFreaks.model.AdminClass;

public class AdminServiceImpl implements AdminService {
	
	//creating obj 
	private AdminRepository  adminrepository;
	

	@Override
	public AdminClass createAdmin(AdminClass adminclass) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AdminClass updateAdmin(AdminClass adminclass) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteAdmin(long AdminId) {
		// TODO Auto-generated method stub
		
	}

}
