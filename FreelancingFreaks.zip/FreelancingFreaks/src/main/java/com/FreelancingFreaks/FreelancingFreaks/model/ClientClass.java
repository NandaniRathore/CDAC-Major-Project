package com.FreelancingFreaks.FreelancingFreaks.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Client")
public class ClientClass {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name="Username")
	private String username;
	
	@Column(name="Email")
	private String email;
	
	@Column(name="Password")
	private String password;
	
	/*
	 * @Column(name="ConfirmPassword") private String confirm_password;
	 * 
	 * public String getConfirm_password() { return confirm_password; }
	 * 
	 * public void setConfirm_password(String confirm_password) {
	 * this.confirm_password = confirm_password; }
	 */
//
//	@Override
//	public String toString() {
//		return "ClientClass [confirm_password=" + confirm_password + "]";
//	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
}
